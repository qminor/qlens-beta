#pragma once
#include <Python.h>
#if PY_MAJOR_VERSION >=3
#define PYTHON3
#endif
